<template>
<div class="container">
  <div class="row">
    <div class="col-12 card">
      <div class="card-body">
        <div class="row">
          <div class="col-12">
            <h3 class="text-primary head_">CV</h3>
          </div>
        </div>
        <div class="row pb-2">
          <div class="col-lg-4 border border-light rounded">
            <div class="row pt-2">
              <div class="col-1">
                <a href="#">
                  <img class="mt-1" src="./Group.png" alt="Group" height="24" width="auto">
                </a>
              </div>
              <div class="col-6">
                <div>
                  <span>CV.pdf</span>
                </div>
                <div>
                  <span class="text-black-50">182 KB</span>
                </div>
              </div>
              <div class="col-2">
                <a href="#">
                  <img class="float-right mt-1" src="./trash.png" height="20" width="auto">
                </a>
              </div>
              <div class="col-2">
                <a href="#">
                  <img class="mr-2 mt-1" src="./download.png" height="20" width="auto">
                </a>
              </div>
            </div>
          </div>
        </div>

        <hr class="py-2">

        <div class="row">
          <div class="col-12">
            <h3 class="text-primary head_">Degree Certificate</h3>
          </div>
        </div>
        <div class="row pb-2">
          <div class="col-lg-4 border border-light rounded">
            <div class="row pt-2">
              <div class="col-1">
                <a href="#">
                  <img class="mt-1" src="./Group.png" alt="Group" height="24" width="auto">
                </a>
              </div>
              <div class="col-6">
                <div>
                  <span>Degree.pdf</span>
                </div>
                <div>
                  <span class="text-black-50">182 KB</span>
                </div>
              </div>
              <div class="col-2">
                <a href="#">
                  <img class="float-right mt-1" src="./trash.png" height="20" width="auto">
                </a>
              </div>
              <div class="col-2">
                <a href="#">
                  <img class="mr-2 mt-1" src="./download.png" height="20" width="auto">
                </a>
              </div>
            </div>
          </div>
        </div>

        <hr class="py-2">

        <div class="row">
          <div class="col-12">
            <h3 class="text-primary head_">NYSC Discharge Certificate</h3>
          </div>
        </div>
        <div class="row pb-2">
          <div class="col-lg-4 border border-light rounded">
            <div class="row pt-2">
              <div class="col-1">
                <a href="#">
                  <img class="mt-1" src="./Group.png" alt="Group" height="24" width="auto">
                </a>
              </div>
              <div class="col-6">
                <div>
                  <span>NYSC.pdf</span>
                </div>
                <div>
                  <span class="text-black-50">182 KB</span>
                </div>
              </div>
              <div class="col-2">
                <a href="#">
                  <img class="float-right mt-1" src="./trash.png" height="20" width="auto">
                </a>
              </div>
              <div class="col-2">
                <a href="#">
                  <img class="mr-2 mt-1" src="./download.png" height="20" width="auto">
                </a>
              </div>
            </div>
          </div>
        </div>

        <hr class="py-2">
        <div class="row">
          <div class="col-12">
            <button class="btn btn-primary float-right px-5">
              Edit Details
            </button>
          </div>
        </div>

      </div>

    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "Resume_CV"
}
</script>

<style scoped>
.border-light {
  border-radius: 4px;
  background-color: #FAFAFC;
}
.head_ {
  font-size: 24px;
}
.btn-primary {
  font-size: 14px;
}
</style>
