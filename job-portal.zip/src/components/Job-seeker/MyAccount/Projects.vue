<template>
<div class="container">
  <div class="row">
    <div class="col-12 card">
      <div class="card-body">

        <div class="row">
          <div class="col-12 py-2">
            <h3 class="text-primary">Experience</h3>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Employe Name</span><br>
            <span class="font_b">ABC Private Limited</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Job Title</span><br>
            <span class="font_b">Sr. Business Analyst</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Duration</span><br>
            <span class="font_b">Jun-2020 till now</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Location</span><br>
            <span class="font_b">Argentina, Buenos Aires</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Industry</span><br>
            <span class="font_b">Healthcare</span>
          </div>
          <div class="col-lg-1">
            <span class="text-black-50 font_a">Work Type</span><br>
            <span class="font_b">Full Time</span>
          </div>
          <div class="col-lg-1">
            <span class="text-black-50 font_a">Salary</span><br>
            <span class="font_b">75,000</span>
          </div>
        </div>
        <div class="row">
          <div class="col-12 pt-4 pb-2">
            <h6 class="text-black-50">Job Responsibility</h6>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-9 pb-2">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Aenean euismod bibendum laoreet.
              Proin gravida dolor sit amet lacus
              accumsan et viverra justo commodo.
              Proin sodales pulvinar sic tempor.
              Sociis natoque penatibus et magnis dis parturient.
            </p>
          </div>
        </div>

        <hr>

        <div class="row">
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Employe Name</span><br>
            <span class="font_b">ABC Private Limited</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Job Title</span><br>
            <span class="font_b">Sr. Business Analyst</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Duration</span><br>
            <span class="font_b">Jun-2020 till now</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Location</span><br>
            <span class="font_b">Argentina, Buenos Aires</span>
          </div>
          <div class="col-lg-2">
            <span class="text-black-50 font_a">Industry</span><br>
            <span class="font_b">Healthcare</span>
          </div>
          <div class="col-lg-1">
            <span class="text-black-50 font_a">Work Type</span><br>
            <span class="font_b">Full Time</span>
          </div>
          <div class="col-lg-1">
            <span class="text-black-50 font_a">Salary</span><br>
            <span class="font_b">75,000</span>
          </div>
        </div>
        <div class="row">
          <div class="col-12 pt-4 pb-2">
            <h6 class="text-black-50">Job Responsibility</h6>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-9 pb-2">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Aenean euismod bibendum laoreet.
              Proin gravida dolor sit amet lacus
              accumsan et viverra justo commodo.
              Proin sodales pulvinar sic tempor.
              Sociis natoque penatibus et magnis dis parturient.
            </p>
          </div>
        </div>

        <div class="row">
          <div class="col-12">
            <button class="btn btn-primary float-right px-5">Edit Details</button>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "Projects"
}
</script>

<style scoped>
.card {
  width: 1400px;
}
/*.border_ {*/
/*  border-radius: 24px;*/
/*}*/
/*.list_ {*/
/*  list-style: none;*/
/*  display: inline;*/
/*  margin-left: -38px;*/
/*}*/
/*.list_ li {*/
/*  display: inline-block;*/
/*}*/
.font_a {
  font-size: 12px;
}
.font_b {
  font-size: 14px;
  font-weight: bold;
}
</style>
