<template>
  <div class="container-fluid">
    <div class="tab-content">
      <div class="tab-content-inner" id="support-messages" role="tabpanel" aria-labelledby="support-messages-tab">
        <div class="message-wrapper">
          <h1 class="meassage">
            Messages
          </h1>
          <div class="input-outer">
            <input class="input" type="text" placeholder="Search Support Messages">
            <img class="search-icon" src="../../../assets/search-icon.png" alt="search">
          </div>
        </div>
        <div class="row row-custom">
          <div class="col-lg-4 col-profile">
            <div class="col-profile-inner">
              <ul class="main-profile-outer">
                <div class="main-without-hover">
                  <li class="profile-inner first-li">
                    <p class="from">From</p>
                    <div class="respond">
                      <a href="" class="responded-by"> Responded by</a>
                      <span class="slash">/</span>
                      <a href="" class="responded-time"> Responded Time</a>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-active">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
                <div class="main-hover">
                  <li class="profile-inner">
                    <div class="profile-name">
                      <div class="img-outer">
                        <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                      </div>
                      <h6 class="profile-name-inner">Ann</h6>
                    </div>
                    <div class="profile-info">
                      <p class="channel">Kianna Press</p>
                      <p class="date">Thu July 04 2020 13:01:58 </p>
                    </div>
                  </li>
                </div>
              </ul>
            </div>
          </div>
          <div class="col-lg-8 col-profile-details">
            <div class="col-profile-details-inner">
              <div class="first-col">
                <div class="profile-name">
                  <div class="img-outer">
                    <img class="img-inner" src="../../../assets/profile-img.png" alt="profile-img">
                  </div>
                  <h6 class="profile-name-inner">Ann</h6>
                </div>
                <div class="respond-by">
                  <p class="respond-by-inner"> Responded by: </p>
                  <a href="" class="username"> Abram Calzoni </a>
                </div>
                <div class="respond-date">
                  <p class="respond-date-inner"> Responded Date: </p>
                  <a href="" class="username"> Thu July 04 2020 13:01:58 </a>
                </div>
                <div class="del-img">
                  <img class="del" src="../../../assets/delete.png" alt="del">
                </div>
              </div>
              <div class="second-message">
                <div class="message-title">
                  <div class="title-inner">
                    <h2 class="title-head">Message title : </h2>
                    <p class="title-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do </p>
                  </div>
                  <div class="message-2nd-outer">
                    <h2 class="message-head">Message:</h2>
                    <p class="message-desc">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                      dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqu
                      ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                      dolore eu fugiat nulla pariatur.
                    </p>
                  </div>
                </div>
              </div>
              <div class="respond-outer">
                <p class="respond-desc-inner">Responded by : <span class="user-name"> “Abram Calzoni” </span></p>
                <p class="respond-desc">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                  ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                  voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                </p>
              </div>
              <div class="comment-outer">
                <textarea class="textarea" name="" cols="30" rows="5" placeholder="Enter your response here..."></textarea>
              </div>
              <div class="action">
                <a class="send-btn" href="">Send</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
name: "myAccount_4"
}

</script>

<style scoped>

.container-fluid{
  padding: 0 80px !important;
  margin-top: 32px;
}

.container-fluid .tile{

}

.container-fluid{

}

.container-fluid .nav-tabs{
  margin: 48px 0 32px 0;
  position:relative;
  border:none!important;
  width: 600px;
}

.container-fluid .nav-tabs .active{
  border-bottom: 3px solid #0385F3 !important;
  color:#0385F3!important;
  border-top: none;
  border-left: none;
  border-right: none;
}

/* #my-account .container-fluid .slider{
    display:inline-block;
    width:30px;
    height:4px;
    border-radius:3px;
    background-color:#0385F3;
    position:absolute;
    z-index:1200;
    bottom:0;
    transition: .1s;
} */

.container-fluid .nav-tabs .nav-item{
  margin:0px!important;
}

.container-fluid .nav-tabs .nav-item .nav-link{
  position:relative;
  margin-right:0px!important;
  padding: 12px 32px!important;
  font-size:16px;
  color:#8B90A0;
  border-bottom: 1px solid #8B90A0;
  font-size: 14px;
}

.container-fluid .nav-tabs .nav-item .nav-link:hover{
  border-bottom: 3px solid #0385F3 !important;
  border-top: none;
  border-left: none;
  border-right: none;
}

/* #my-account .container-fluid .nav-tabs .nav-link {
    border: none !important;
    border-bottom: 1px solid #8B90A0 !important;
} */



.container-fluid .tab-content{

}

.container-fluid .tab-content .tab-content-inner{

}

.container-fluid .tab-content .tab-content-inner .message-wrapper{
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
}

.container-fluid .tab-content .tab-content-inner .message-wrapper .meassage{
  font-size: 32px;
  line-height: 48px;
  color: #505565;
}

.container-fluid .tab-content .tab-content-inner .message-wrapper .input-outer{
  position: relative;
  width: 420px;
}

.container-fluid .tab-content .tab-content-inner .message-wrapper .input-outer .input{
  width: 100%;
  padding: 12px 14px 12px 44px;
  color: #8B90A0;
  border-radius: 4px;
  border: 1px solid #8B90A0;
  outline: none;
  box-shadow: none;
}

.container-fluid .tab-content .tab-content-inner .message-wrapper .input-outer .input::placeholder{
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .message-wrapper .input-outer .search-icon{
  position: absolute;
  top: 50%;
  left: 16px;
  transform: translate(0, -50%);
}

.container-fluid .tab-content .tab-content-inner .row-custom{
  margin: 20px 0 130px 0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile{
  padding: 0 40px 0 0 !important;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer{
  border: 1px solid #F0F1F3;
  padding: 0;
  /* height: 917px;
  overflow-y: scroll; */
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .main-without-hover{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .main-hover{
  border-right: 3px solid transparent;
  transition: .3s;
}
.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .main-active{
  background: linear-gradient(270deg, rgba(3, 133, 243, 0.1) 0%, rgba(3, 133, 243, 0) 100%);
  border-right: 3.5px solid #0385F3;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner{
  border-bottom: 1px solid #F0F1F3;
  display: flex;
  align-items: center;
  padding: 18px 0;
  margin: 0 32px;
  position: relative;
  transition: .3s;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .first-li{
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 32px 32px 0 32px;
  padding-bottom: 20px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .first-li .from{
  font-size: 14px;
  line-height: 24px;
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .first-li .respond{
  font-size: 14px;
  line-height: 24px;
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .first-li .respond .responded-by{
  font-size: 14px;
  line-height: 24px;
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .first-li .respond .slash{
  font-size: 14px;
  line-height: 24px;
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .first-li .responded-time{
  font-size: 14px;
  line-height: 24px;
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-name{
  display: flex;
  align-items: center;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-name .img-outer{
  width: 40px;
  height: 40px;
}


.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-name .img-outer .img-inner{
  border-radius: 100%;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-name .profile-name-inner{
  padding-left: 20px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-info{
  padding-left: 60px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-info .channel{
  font-size: 14px;
  line-height: 24px;
  color: #555555;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile .col-profile-inner .main-profile-outer .profile-inner .profile-info .date{
  font-size: 14px;
  line-height: 24px;
  color: #555555;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col{
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #C4C4C4;
  padding: 16px 60px 16px 60px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .profile-name{
  display: flex;
  align-items: center;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .profile-name .img-outer{
  width: 40px;
  height: 40px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .profile-name .img-outer .img-inner{
  border-radius: 100%;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .profile-name .profile-name-inner{
  font-size: 14px;
  line-height: 24px;
  color: #555555;
  padding-left: 20px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .respond-by{
  display: flex;
  align-items: center;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .respond-by .respond-by-inner{
  color: #8B90A0;
  font-size: 14px;
  line-height: 24px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .respond-by .username{
  color: black;
  font-size: 14px;
  line-height: 24px;
  margin-left: 5px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .respond-date{
  display: flex;
  align-items: center;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .respond-date .respond-date-inner{
  color: #8B90A0;
  font-size: 14px;
  line-height: 24px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .first-col .respond-date .username{
  color: black;
  font-size: 14px;
  line-height: 24px;
  margin-left: 5px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message{
  padding: 40px 0px 32px 0px;
  margin: 0 60px;
  border-bottom: 1px solid #D3D4D8;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title .title-inner{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title .title-inner .title-head{
  font-size: 18px;
  line-height: 24px;
  color: black;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title .title-inner .title-desc{
  font-size: 16px;
  line-height: 24px;
  color: #8B90A0;
  margin: 10px 0 32px 0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title .message-2nd-outer{

}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title .message-2nd-outer .message-head{
  font-size: 18px;
  line-height: 24px;
  color: black;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .second-message .message-title .message-2nd-outer .message-desc{
  font-size: 16px;
  line-height: 24px;
  color: #8B90A0;
  padding: 10px 0 0 0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .respond-outer{
  margin: 0 60px;
  padding: 32px 0 0 0;
}

#my-account .container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .respond-outer .respond-desc-inner{
  font-size: 18px;
  line-height: 24px;
  color: #8B90A0;
  padding: 0 0 10px 0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .respond-outer .respond-desc-inner .user-name{
  color: #0385F3;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .respond-outer .respond-desc{
  font-size: 16px;
  line-height: 24px;
  color: #8B90A0;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .comment-outer{
  padding: 48px 0 0 0;
  margin: 0 60px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .comment-outer .textarea{
  padding: 16px;
  border: 1px solid #A1A4B1;
  width: 100%;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .action{
  display: flex;
  justify-content: flex-end;
  margin: 0 60px;
}

.container-fluid .tab-content .tab-content-inner .row-custom .col-profile-details .col-profile-details-inner .action .send-btn{
  padding: 16px 32px;
  background-color: #0385F3;
  color: white;
  width: 200px;
  text-align: center;
  justify-content: center;
  margin-top: 20px;
}
</style>
