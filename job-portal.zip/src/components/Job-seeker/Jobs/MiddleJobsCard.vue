<template>
  <div class="container-fluid mt-5">

    <div class="card my-5">
      <div class="card-body">
        <div class="position-absolute new_feature_box">
          Featured
        </div>
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card my-5">
      <div class="card-body">
        <div class="position-absolute new_feature_box">
          Featured
        </div>
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card my-5">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card my-5">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card my-5">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card my-5">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card my-5">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-1">
            <img src="../../../assets/google-icon 1.png" class="google" height="60" width="auto"/>
          </div>
          <div class="col-11">
            <div class="row">
              <div class="col-lg-5">
                <h4 class="front-end-developer">Front-end Developer</h4>
              </div>
              <div class="col-lg-3">
                <p class="text-black-50">Google India Private Limited</p>
              </div>
              <div class="col-lg-2">
                <img src="../../../assets/clock.png" height="16" width="17"/>
                <span>2 days Ago</span>
              </div>
              <div class="col-lg-2">
                <p class="border border-primary bg-primary text-white text-center my-2">Part Time</p>
              </div>
            </div>

            <div class="row">
              <div class="col-3">
                <p class="border border-light bg-light text-black-50 text-center web-development">Web
                  Development</p>
              </div>
              <div class="col-md-3">
                <div class="">
                  <img src="../../../assets/Group.png" height="24" width="20"/>
                  <span class="text-black-50">2-5 Years</span>
                </div>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/n-icon.png" height="14" width="16"/>
                <span class="text-black-50">2000 - 6000</span>
              </div>
              <div class="col-md-3">
                <img src="../../../assets/map-pin.png" height="16" width="auto"/>
                <span class="text-black-50">Ibadan & Oyo State</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


  </div>
</template>

<script>
export default {
  props: ["isFeatured", "image", "isPartTime"],
};
</script>

<style scoped>
.new_feature_box {
  text-align: center;
  padding: 0px 8px;
  top: -12px;
  right: 12px;
  width: 80px;
  /*width: 50px;*/
  height: 22px;
  background: #ff4c68;
  border-radius: 2px;
  color: #FAFAFA;
}
@media screen and (max-width: 1037px){
  .web-development {
    width: 90px;
  }
}
@media screen and (max-width: 1315px) and (min-width: 991px){
.front-end-developer {
  padding-left: 20px;
}
}
@media screen and (max-width: 768px) and (min-width: 332px){
.web-development {
  width: 200px;
}
}
@media screen and (max-width: 331px){
.web-development {
  width: 120px;
}
}
</style>
