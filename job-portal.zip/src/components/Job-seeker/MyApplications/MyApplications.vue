<template>
<div class="container-fluid">
  <div class="row py-3">
    <div class="col-sm-5">
      <div class="row pt-3">
        <div class="col-md-3 border border-light rounded m-2 border_a">
          <div>
            <span class="font_c">25</span>
          </div>
          <div>
            <span class="text-black-50 font_b">Applications</span>
          </div>
        </div>
        <div class="col-md-3 border border-light rounded m-2 border_a">
          <div>
            <span class="font_c">05</span>
          </div>
          <div>
            <span class="text-black-50 font_b">Shortlisted</span>
          </div>
        </div>
        <div class="col-md-4 border border-light rounded m-2 border_a">
          <div>
            <span class="font_c">15</span>
          </div>
          <div>
            <span class="text-black-50 font_b">Not Seen Yet</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-4 font_c">
      <h3>My Applications</h3>
    </div>
  </div>
  <div class="row pt-2">

    <div class="col-lg-4 mt-3">
      <div class="card card-body">
        <div class="row">
          <div class="col-12">
            <div>
              <span class="font_d">Business Development Manager</span>
            </div>
            <div>
              <span class="text-black-50 font_a">Google India Private Limited</span>
            </div>
          </div>
        </div>
        <div class="row py-3">
          <div class="col-md-7">
            <img src="./map-pin.png" height="20" width="22"/>
            <span class="text-black-50 font_a">Ibadan & Oyo State</span>
          </div>
          <div class="col-md-5">
            <span class="text-primary border border-light rounded font_b pb-1 recruiter_last_online">Recruiter last online 24 mins ago</span>
          </div>
        </div>

        <hr>

        <div class="row">
          <div class="col-12">
            <div>
              <span class="font_d">Business Development Manager</span>
            </div>
            <div>
              <span class="text-black-50 font_a">Google India Private Limited</span>
            </div>
          </div>
        </div>
        <div class="row py-3">
          <div class="col-md-7">
            <img src="./map-pin.png" height="20" width="22"/>
            <span class="text-black-50 font_a">Ibadan & Oyo State</span>
          </div>
          <div class="col-md-5">
            <span class="text-primary border border-light rounded font_b pb-1 recruiter_last_online">Recruiter last online 24 mins ago</span>
          </div>
        </div>

        <hr>

        <div class="row">
          <div class="col-12">
            <div>
              <span class="font_d">Business Development Manager</span>
            </div>
            <div>
              <span class="text-black-50 font_a">Google India Private Limited</span>
            </div>
          </div>
        </div>
        <div class="row py-3">
          <div class="col-md-7">
            <img src="./map-pin.png" height="20" width="22"/>
            <span class="text-black-50 font_a">Ibadan & Oyo State</span>
          </div>
          <div class="col-md-5">
            <span class="text-primary border border-light rounded font_b pb-1 recruiter_last_online">Recruiter last online 24 mins ago</span>
          </div>
        </div>

        <hr>

        <div class="row">
          <div class="col-12">
            <div>
              <span class="font_d">Business Development Manager</span>
            </div>
            <div>
              <span class="text-black-50 font_a">Google India Private Limited</span>
            </div>
          </div>
        </div>
        <div class="row py-3">
          <div class="col-md-7">
            <img src="./map-pin.png" height="20" width="22"/>
            <span class="text-black-50 font_a">Ibadan & Oyo State</span>
          </div>
          <div class="col-md-5">
            <span class="text-primary border border-light rounded font_b pb-1 recruiter_last_online">Recruiter last online 24 mins ago</span>
          </div>
        </div>

        <hr>

        <div class="row">
          <div class="col-12">
            <div>
              <span class="font_d">Business Development Manager</span>
            </div>
            <div>
              <span class="text-black-50 font_a">Google India Private Limited</span>
            </div>
          </div>
        </div>
        <div class="row pt-3">
          <div class="col-md-7">
            <img src="./map-pin.png" height="20" width="22"/>
            <span class="text-black-50 font_a">Ibadan & Oyo State</span>
          </div>
          <div class="col-md-5">
            <span class="text-primary border border-light rounded font_b pb-1 recruiter_last_online">Recruiter last online 24 mins ago</span>
          </div>
        </div>

      </div>
    </div>
<!--    <div class="col-1">-->
<!--    </div>-->
    <div class="col-lg-7">
      <div class="ml-xl-2 mt-lg-n5 mt-xl-n5 mt-sm-5">
      <div class="row">
        <div class="col-lg-5 font_c">
          <h3>Job Application Status</h3>
        </div>
        <div class="col-lg-4">
          <div class="border border-light rounded border_a pl-4 pt-1 pb-2 pr-md-0">
            <div class="row">
              <div class="mt-1">
                <img src="./info.png" height="24" width="24">
              </div>
              <div class="font_e ml-2">
                <span>Not getting views on your CV?</span><br>
                <span>Keep your profile updated</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3">
          <button class="btn btn-primary button_">
            Update Profile
          </button>
        </div>
      </div>
      <hr>
      <div class="row ">
        <div class="col-md-6">
          <div>
            <span class="font_d">Business Development Manager</span>
          </div>
          <div>
            <span class="text-black-50 font_a">Google India Private Limited</span>
          </div>
        </div>
        <div class="col-3">
        </div>
        <div class="col-lg-3">
          <button type="button" class="btn border border-primary text-primary button_">
            View Similar Jobs
          </button>
        </div>
      </div>
      <div class="row py-4">
        <div class="col-lg-8">
          <img src="./map-pin.png" height="20" width="22"/>
          <span class="text-black-50 font_a">Ibadan & Oyo State</span>
        </div>
        <div class="col-lg-4">
          <span class="text-primary border border-light rounded font_b pb-1 recruiter_last_online">Recruiter last online 24 mins ago</span>
        </div>
      </div>
      <hr>
      <div class="row">
        <div class="col-12">
          <span class="text-black-50 font_d">Application Status</span>
        </div>
      </div>
      <div class="row py-2">
        <div class="col-12">
          <ul class="progressbar">
            <li class="active">
              <div>
                <span>Applied for the Job</span>
              </div>
              <div>
                <span class="text-black-50">05 Jun'20 12:45 PM</span>
              </div>
            </li>
            <li class="active">
              <div>
                <span>Recruiter viewed on</span>
              </div>
              <div>
                <span class="text-black-50">10 Jun'20 12:45 PM</span>
              </div>
            </li>
            <li class="text-black-50">
              <div>
                <span>Shortlisted On</span>
              </div>
              <div>
                <span>Awaiting</span>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <hr>
      <div class="row py-4">
        <div class="col-12">
          <span class="text-black-50 font_d">Activity on this Job</span>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2 ml-2 mr-2">
          <div class="font_c">
            <span>150</span>
          </div>
          <div class="font_b">
            <span class="text-black-50">Total Applications</span>
          </div>
        </div>
        <div class="col-md-3 ml-2 mr-2">
          <div class="font_c">
            <span>150</span>
          </div>
          <div class="font_b">
            <span class="text-black-50">Applications Viewed</span>
          </div>
        </div>
        <div class="col-md-3 ml-2 mr-2">
          <div class="font_c">
            <span>8</span>
          </div>
          <div class="font_b">
            <span class="text-black-50">Candidates Shortlisted</span>
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "MyApplications"
}
</script>

<style scoped>
@import url(https://fonts.googleapis.com/css?family=Roboto:700);

/*body {*/
/*  background-color: #2979FF;*/

/*}*/

/*.container {*/
/*  width: 100%;*/
/*  color: #0385F3;*/
/*  !*background: #2979FF;*!*/
/*  font-family: 'Roboto', sans-serif;*/
/*  margin-top: 20%;*/
/*}*/
.container-fluid {
  padding-bottom: 50px;
}

.progressbar {
  counter-reset: step;
  width: auto;

  }

.progressbar li {
  position: relative;
  list-style: none;
  float: left;
  width: 33.3%;
  text-align: center;
}

/* Circles */
.progressbar li:before {
  content: "";
  counter-increment: step;
  width: 30px;
  height: 30px;
  border: 1px solid ;
  display: block;
  text-align: center;
  margin: 0 auto 10px auto;
  border-radius: 50%;
  background-color: white;

  /* Center # in circle */
  line-height: 30px;
}

.progressbar li:after {
  content: "";
  position: absolute;
  width: 50%;
  height: 0px;
  /*   background: orange ; */
  top: 40px; /*half of height Parent (li) */
  left: -25%;
  z-index: -1;
  border: 1px solid;
  border-color: #5AAADF;
}

.progressbar li:first-child:after {
  content: none;
}

.progressbar li.active:before {
  background-color: #5AAADF;
  color: #ffffff;
  content: "✔";
}

.progressbar li.active + li:after {
  /*   background:  #00E676; */
  /*   border-bottom: 1px dashed */
  /*border-color: #00E676;*/
}
.container-fluid {
  font-family: Open Sans;
}
.border_a {
  border-radius: 4px;
  background: #FAFDFF;
}
.font_a {
  font-size: 14px;
}
.font_b {
  font-size: 12px;
}
.font_c {
  font-size: 24px;
  font-weight: bold;
}
.font_d {
  font-size: 18px;
  font-weight: bold;
}
.font_e {
  font-size: 11px;
}
.recruiter_last_online {
  background-color:  #FAFDFF;
}
@media screen and (max-width: 992px){
h3 {
margin-top: 30px;
}
  .button_ {
    margin-top: 20px;
  }
}
</style>
