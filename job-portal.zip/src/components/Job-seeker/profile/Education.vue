<template>
  <div class="container">
    <a-form :form="form" @submit="handleSubmit">
      <div class="row justify-content-center mt-3">
        <div class="col-12">
          <h4 class="pl-1">Enter Education Details</h4>
        </div>
      </div>
      <a-form-item>
        <div class="form-group ml-1">
          <div class="row">
            <div class="col-sm-6">
              <a-input v-decorator="[`Degree`,]"
                       type="text" class="my-2 form-control" id="degree" placeholder="Degree/Certification">
              </a-input>
            </div>
            <div class="col-sm-6">
              <a-input v-decorator="[`College`,]"
                       type="text" class="my-2 form-control" id="college" placeholder="College/University/Academy">
              </a-input>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <a-date-picker
                v-decorator="[`EndDate`,]"
                             class="my-2 w-100" @change="onChange" placeholder="End Date"/>
            </div>
            <div class="col-sm-6">
              <a-date-picker v-decorator="[`StartDate`,]"
                             class="my-2 w-100" @change="onChange" placeholder="Start Date"/>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <a-textarea v-decorator="[`EducationDetail`,]"
                          class="form-control my-2"
                          name="text"
                          id="education_details"
                          cols=""
                          rows="6"
                          placeholder="Education Details">

              </a-textarea>
            </div>
          </div>
          <div class="row justify-content-center text-center my-2">
            <div class="col-12">
              <button class="btn btn-light">
                Add More Education
              </button>
            </div>
          </div>
        </div>
      </a-form-item>
      <hr>
      <div class="row float-right">
        <div class="col-12">
          <a-button class="login-button-style btn btn-light px-4" @click="changed(1)">Go Back</a-button>
          <a-button type="primary"
                    html-type="submit"
                    class="login-button-style btn btn-primary px-4"
                    :disabled="hasErrors(form.getFieldsError())"
                    >Proceed
          </a-button>
        </div>
      </div>
    </a-form>
  </div>
</template>

<script>
import axios from "axios";

function hasErrors(fieldsError) {
  return Object.keys(fieldsError).some((field) => fieldsError[field]);
}
export default {
  el: "Education",

  data() {
    return {
      hasErrors,
      form: this.$form.createForm(this, { name: "Degree College EndDate StratDate EducationDetail" }),
    };
  },

  methods: {
    changed: function (step) {
      this.$store.commit('change', step)
    },
    userNameError() {
      const { getFieldError, isFieldTouched } = this.form;
      return isFieldTouched("userName") && getFieldError("userName");
    },
    // Only show error after a field is touched.
    handleSubmit(e) {
      e.preventDefault();
      this.form.validateFields((err, values) => {
        if (!err) {
          let StartDate = values.StartDate.toDate()
          let EndDate = values.EndDate.toDate()
          values.StartDate = StartDate
          values.EndDate = EndDate
          console.log("Received values of form: ", values);
          this.$store.commit('change', 3)
        }
      });

      var data = values
      var config = {
        method: 'post',
        url: 'http://167.99.198.38:32001/create/job/seeker/education',
        headers: {
          'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFZ0NPRTB3ZDVEMjZfX0ZUZURmSmhNejlucndZYXM2czFGaE5EcHo2djFJIn0.eyJleHAiOjE2MTEyMzAwMTksImlhdCI6MTYxMTIyNjQxOSwianRpIjoiMTU2YWM2OTktZjNiNS00MDQ1LWIwYWEtMzJlZTNmNTQ0Mjc0IiwiaXNzIjoiaHR0cDovLzE3OC42Mi44Ny4xNjI6ODA4MC9hdXRoL3JlYWxtcy9tYXN0ZXIiLCJzdWIiOiI3ZDVhOTc2NC1kN2RiLTQ2ZTktYTdjMi01ZTdmNWZlOGUwMDYiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJhZG1pbi1jbGkiLCJzZXNzaW9uX3N0YXRlIjoiNDM3MmU1ZmUtOTA5Zi00YTQwLWE4MzYtMzk0NzMxYjBmM2RiIiwiYWNyIjoiMSIsInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIiwiSk9CU0VFS0VSIl19LCJzY29wZSI6InByb2ZpbGUgZW1haWwiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwibmFtZSI6IlRvbnkgQXlhYmFtIiwicHJlZmVycmVkX3VzZXJuYW1lIjoidG9ueUBnbWFpbC5jb20iLCJnaXZlbl9uYW1lIjoiVG9ueSIsImZhbWlseV9uYW1lIjoiQXlhYmFtIiwiZW1haWwiOiJ0b255QGdtYWlsLmNvbSJ9.oriQrwqrbp8R94vQJcl2XuY4wlRYcCzelIAaZiSfz78B-ryUGQU3p4lpkRGZpdU_lrBRgUTB4kteIp5uHfb2XQ9iUnghKuwIIMR46jOBmDptk8P1sNHIVEYq-61XMHmfQrwyPnkY2ufxRVCWv8wV0onKrHSD6jepwvp8Opkm-4xZY5ZaRpAVzGAJwj-WRNVI3NPg5wOsCUgTzhXyguBAHko_uMoXug-oHOKiMStoyjQ068McwaoHKiu93SWZ6fxNS0IQwmw6Q4MG2KuKMiyCGNd8fjxPjEOXNsF1TUifyGHXq2zRHU4hbP92QBDShRaANqONZEK6pQLnQeM3e0PQig',
          'Content-Type': 'application/json'
        },
        data : data
      };
      axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));

        })
        .catch(function (error) {
          console.log(error);
        });

    },
    onChange(date, dateString) {
      console.log("date", dateString);
    },
  },
}
</script>

<style scoped>
@media screen and (max-width: 242px) {
  .login-button-style {
    margin-bottom: 5px ;
    width: 100%;
  }
}
</style>
