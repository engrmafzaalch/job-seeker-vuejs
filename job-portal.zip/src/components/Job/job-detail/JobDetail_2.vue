<template>
<div class="container">
  <div class="row business_analyst_job">
    <div class="col-12">
      <h6>HOME / <span class="text-primary">BUSINESS ANALYST JOB</span></h6>
    </div>
  </div>
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-body">
          <div class="row">
            <div class="col-lg-2">
              <img class="ml-2" src="./google-icon.png" height="80" width="auto"/>
            </div>
            <div class="col-md-10">
              <div class="row">
                <div class="col-md-9">
                  <h2 class="one">Business Analyst</h2>
                </div>
                <div class="col-sm-3">
                  <p class="border text-white border-primary text-center part_time py-1 ml-2">Part Time</p>
                </div>
              </div>
              <div class="row two">
                <div class="col-lg-4">
                  <img src="./map-pin.svg" alt="map pin"/>
                  <span class="text-black-50 ml-1">Abuja , Nigeria</span>
                </div>
                <div class="col-lg-4">
                  <img src="./clock.svg" alt="clock"/>
                  <span class="text-black-50 ml-1">2 Hours Ago</span>
                </div>
                <div class="col-lg-4">
                  <img src="./dollar-sign.svg" alt="dollar sign">
                  <span class="text-black-50 ml-1">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>

          <hr>


          <div class="row">
            <div class="col-lg-2">
              <p class="text-black-50">Opening: <a href="#" class="text-primary">12</a></p>
            </div>
            <div class="col-lg-3">
              <p  class="text-black-50">Job Applicants: <a href="#" class="text-primary">1258</a></p>
            </div>
            <div class="col-4">

            </div>
            <div class="col-lg-3">
              <p class="text-black-50">Posted 20 days ago</p>
            </div>
          </div>
          <hr>
          <div class="row">
            <div class="col-12 description">
              <h3>Description</h3>
            </div>
          </div>
          <div class="row">
            <div class="col-12 role_and_responsibility">
              <h4>The roles and responsibilities for Business Analyst:</h4>
            </div>
          </div>
          <div class="row unorder_list">
            <div class="col-lg-9 text-muted">
              <ul>
                <li>Review, analyse, evaluate and prioritize business requirements</li>
                <li>Document requirements, define scope, create impactful presentations as well as insightful spreadsheets</li>
                <li>Design workflow charts/diagrams, evaluate system capabilities, write specifications</li>
                <li>End to end project management: Define project tasks, actively track project progress, and milestones, publish periodic progress reports, recommend actions</li>
                <li>Prepare technical reports by collecting, analysing and summarizing information</li>
                <li>Conduct cost/benefit analysis</li>
                <li>Act as a Finance process SME, and suggest process improvements based on experience in applying industry best practices at scale</li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div class="col-12">
              <h4>Should have knowledge of:</h4>
            </div>
          </div>
          <div class="row unorder_list">
            <div class="col-lg-9 text-muted">
              <ul>
                <li>Knowledge of Agile development</li>
                <li>Knowledge of Finance processes and financial enterprise systems</li>
                <li>Well versed with tools such as JIRA</li>
                <li>Excellent written and verbal communication, including technical writing skills</li>
                <li>Mastery in documentation using MS Office suite (Excel/PPT/Word)</li>
                <li>Business case development</li>
                <li>Data analysis, reporting</li>
                <li>Stakeholder management</li>
              </ul>
            </div>
          </div>

          <hr>

          <div class="row description">
            <div class="col-12">
              <h3>Education</h3>
            </div>
          </div>
          <div class="row education_data">
            <div class="col-12">
              <div class="mb-3">
              <span style="font-weight: bold">UD :</span>
              <span class="text-muted">B.Tech</span>
              </div>
              <div>
                <span style="font-weight: bold">PG :</span>
                <span class="text-muted">Post Graduation Not Required</span>
              </div>
            </div>
          </div>

          <hr>

          <div class="row">
            <div class="col-12">
              <h3>Requirement</h3>
            </div>
          </div>
          <div class="row unorder_list">
            <div class="col-12">
              <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
            </div>
          </div>

          <div class="row">
            <div class="col-12 unorder_list">

              <div>
                  <input type="checkbox" checked>
                  <span class="ml-2">Laboris laboris nostrud consect etur magna.</span>
              </div>

              <div>
                  <input type="checkbox" checked>
                  <span class="ml-2">Laboris laboris nostrud consect etur magna. Aliqua sint dolore esse ut occaecat do.</span>
              </div>

              <div>
                <input type="checkbox" checked>
                <span class="ml-2">Laboris laboris nostrud consect etur magna.</span>
              </div>

            </div>
          </div>

          <hr>

          <div class="row description">
            <div class="col-12">
              <h3>Skills</h3>
            </div>
          </div>

          <div class="row">
            <div class="border_ text-center m-1">C</div>
            <div class="border_ text-center m-1">C++</div>
            <div class="border_ text-center m-1">JAVA</div>
            <div class="border_ text-center m-1">SQL</div>
            <div class="border_ text-center m-1">Windows Server-2008</div>
          </div>

          <hr>

          <div class="row">
            <div class="col-12">
              <h3>About Company</h3>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-9 unorder_list">
              <p>
                Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
              </p>
            </div>
          </div>

          <hr>

          <div class="row">
            <div class="col-12 description">
              <h3>Perks and Benefits </h3>
            </div>
          </div>
          <div class="row">
            <div class="col-12 benefits">
              <div class="row mb-2">
                <div class="col-lg-4">
                <input type="checkbox" checked>
                <span class="mr-2">Lunch</span>
                </div>

                <div class="col-lg-3">
                <input type="checkbox" checked>
                <span class="mr-2">Healthcare</span>
                </div>

                <div class="col-lg-5">
                <input type="checkbox" checked>
                <span>Vacation/Paid Time Off</span>
                </div>
              </div>
              <div class="row my-2">
                <div class="col-lg-6">
                <input type="checkbox" checked>
                <span>Gym Membership</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="row">
        <div class="col-12">
          <a-button @click="showModal" class="button_ my-3">Apply For This Position Now</a-button>
          <a-modal v-model="visible" @ok="handleOk" :footer="null">
            <div class="row pl-4">
              <div class="col-12">
                <input type="checkbox" class="form-check-input" value=""/>
                <h5>Continue with my CV</h5>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-12">
                <h3>Apply with new CV</h3>
              </div>
            </div>
            <div class="jumbotron justify-content-center text-center">
              <div class="row">
                <div class="col-12">
                  <img src="../../Job-seeker/profile/upload.png" height="40" width="42"/>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <div>
                    <span>Drop your CV here , or <a href="#">browse</a></span>
                  </div>
                  <div>
                    <span>Support: PDF, JPGS, DOCS</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-6">
                <a-button class="btn-block" @click="hideModal">
                  Cancel
                </a-button>
              </div>
              <div class="col-6">

                <a-button @click="showModal1" type="primary" class="btn-block">
                  Apply
                </a-button>

                <a-modal v-model="visible1" :footer="null">
                  <div class="row my-2">
                    <div class="col-12 text-center">
                      <img src="./tick mark.png" height="64" width="65"/>
                    </div>
                  </div>
                  <div class="row my-3">
                    <div class="col-12 text-center">
                      <p>You have successfully applied for <br>
                        "Business Analyst Position" at Google India Private Limited
                      </p>
                    </div>
                  </div>
                  <div class="row my-3">
                    <div class="col-12 text-center">
                      <a-button @click="hideModal1" type="primary" class="px-5">Go to Your Applications</a-button>
                    </div>
                  </div>
                </a-modal>

              </div>
            </div>
          </a-modal>
        </div>
      </div>


      <div class="row">
        <div class="col-12">
          <p>or apply via Email</p>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-12">
          <a href="mailto:Careers@google.com" class="email">Careers@google.com</a>
        </div>
      </div>

      <div class="row">
        <div class="col-12">
          <div style="display: flex">
            <button type="button" class="btn btn-light px-4 mr-2"><img src="./share.svg" alt="share" class="mr-2">Share</button>
            <button type="button" class="btn btn-light px-4 mr-2"><img src="./tweeter.svg" alt="tweeter" class="mr-2">Tweet</button>
            <button type="button" class="btn btn-light px-4"><img src="./save.svg" alt="save" class="mr-2">Save</button>
          </div>
        </div>
      </div>

      <div class="row mt-3">
        <div class="col-12">
          <p class="description float-left" style="font-weight: bold">Jobs You Might Be Interested In</p>
        </div>
      </div>

        <div class="card position-relative featured-jobs">
          <div class="card-body">
            <div class="position-absolute new_feature_box">
              New
            </div>
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                    <img src="./dollar-sign-light.svg" alt="dollar sign">
                    <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card mt-2 featured-jobs">
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div>
                  <img src="./Rectangle 11.png" height="60" width="60"/>
                  <span class="pt-3 pl-2 front_end_developer">Front-end Developer</span>
                </div>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-6">
                <div>
                  <img src="./map-pin-light.svg" alt="map pin" height="16" width="15"/>
                  <span class="pl-2 text-muted location">Abuja , Nigeria</span>
                </div>
              </div>
              <div class="col-lg-6">
                <div>
                  <img src="./dollar-sign-light.svg" alt="dollar sign">
                  <span class="text-muted location">2000 - 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "JobDetail_2",

  data() {
    return {
      visible: false,
      visible1: false,
    };
  },
  methods: {
    showModal() {
      this.visible = true;
    },
    hideModal() {
      this.visible = false;
    },
    handleOk(e) {
      console.log(e);
      this.visible = false;
    },
    showModal1() {
      this.visible = false;
      this.visible1 = true;
    },
    hideModal1() {
      this.visible1 = false;
    },
  },
};
</script>

<style scoped>
.container {
  font-family: "Open Sans";
  padding-bottom: 50px;
}
.business_analyst_job {
  font-size: 14px;
}
.part_time {
  background-color: #0385F3;
  border-radius: 2px;
  font-size: 12px;
}
.one {
  font-size: 28px;
}
.two {
  font-size: 14px;
}
.description {
  font-size: 22px;
}
.role_and_responsibility {
  font-size: 18px;
}
.unorder_list {
  font-size: 16px;
}
.education_data {
  font-size: 18px;
}
.border-light {
  border-radius: 24px;
}
.benefits {
  font-size: 18px;
  font-weight: bold;
}
.button_ {
  background-color: #00C87A;
  color: white;
}
.email {
  color: #00C87A;
}
.btn-light {
  font-size: 12px;
}
.front_end_developer {
  font-size: 16px;
  font-weight: bold;
}
.location {
  font-size: 14px;
}
.new_feature_box {
  text-align: center;
  padding: 0px 8px;
  top: -12px;
  right: 12px;
  width: 50px;
  /*width: 50px;*/
  height: 22px;
  background: #ff4c68;
  border-radius: 2px;
  color: #FAFAFA;
}
.border_ {
  border-radius: 24px;
  background-color: #FAFAFC;
  padding: 10px 25px;
}
/*.color_new_feature_job_text {*/
/*  font-family: Open Sans;*/
/*  font-style: normal;*/
/*  font-weight: 600;*/
/*  font-size: 14px;*/
/*}*/
li {
  margin-bottom: 10px;
}

.featured-jobs {
  margin: 20px 0px;
}
</style>
