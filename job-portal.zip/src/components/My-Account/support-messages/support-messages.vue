<template>
  <div class="container vh-100">
    <div class="row justify-content-start">
      <div class="col-12 mt-3  messages">
        <h4>Messages</h4>
      </div>
    </div>

      <div class="row mt-3">
        <div class="col-5">
          <div class="card">
            <div class="card-body">
              <div class="card-title">
                <span>FROM</span>
              <span class="float-right">RESPONDED BY/RESPOND TIME</span></div>
              <hr>
              <div>
              <img class="card-image" src="img" alt="img">
              <span class="card-text">Ann</span>
              <span class=""></span>
              </div>
            </div>
          </div>
          </div>
          <div class="col-7">

          </div>

      </div>

    </div>
</template>

<script>
export default {
  name: "support_messages"
}
</script>

<style scoped>

</style>
